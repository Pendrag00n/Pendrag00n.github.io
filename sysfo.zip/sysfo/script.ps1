
echo " " | Out-File -FilePath "output.txt" -Append
echo "  EQUIPO Y LICENCIA(s) <--" | Out-File -FilePath "output.txt" -Append
echo " " | Out-File -FilePath "output.txt" -Append
Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object Username, Model | Out-File -FilePath "output.txt" -Append
Get-NetIPAddress -AddressFamily IPV4 | Select-Object IPAddress | Out-File -FilePath "output.txt" -Append
(Get-WmiObject -Class Win32_OperatingSystem).Caption | Out-File -FilePath "output.txt" -Append
(Get-WmiObject -query 'select * from SoftwareLicensingService').OA3xOriginalProductKey | Out-File -FilePath "output.txt" -Append
echo "DigitalProductId4: " | Out-File -FilePath "output.txt" -Append
echo " " | Out-File -FilePath "output.txt" -Append
echo "  PROCESADOR <--" | Out-File -FilePath "output.txt" -Append
Get-WMIObject -Class Win32_Processor | Select-Object Name, SocketDesignation | Out-File -FilePath "output.txt" -Append
echo "  MEMORIA <--" | Out-File -FilePath "output.txt" -Append
Get-WmiObject -Class Win32_PhysicalMemory | Select-Object Manufacturer, @{Name="Size (GB)"; Expression={$_.Capacity/1GB}}, @{Name="FormFactor"; Expression={switch($_.FormFactor) {1 {'Other'}; 2 {'SIP'}; 3 {'DIP'}; 4 {'ZIP'}; 5 {'SOJ'}; 6 {'Proprietary'}; 7 {'SIMM'}; 8 {'DIMM'}; 9 {'TSOP'}; 10 {'PGA'}; 11 {'RIMM'}; 12 {'SODIMM'}; 13 {'SRIMM'}; 14 {'SMD'}; 15 {'SSMP'}; 16 {'QFP'}; 17 {'TQFP'}; 18 {'SOIC'}; 19 {'LCC'}; 20 {'PLCC'}; 21 {'BGA'}; 22 {'FPBGA'}; 23 {'LGA'}}}}, @{Name="MemoryType"; Expression={switch($_.MemoryType) {0 {'Undefined'}; 1 {'Other'}; 2 {'Unknown'}; 3 {'DRAM'}; 4 {'EDRAM'}; 5 {'VRAM'}; 6 {'SRAM'}; 7 {'RAM'}; 8 {'ROM'}; 9 {'Flash'}; 10 {'EEPROM'}; 11 {'FEPROM'}; 12 {'EPROM'}; 13 {'CDRAM'}; 14 {'3DRAM'}; 15 {'SDRAM'}; 16 {'SGRAM'}; 17 {'RDRAM'}; 18 {'DDR'}; 19 {'DDR2'}; 20 {'DDR2 FB-DIMM'}; 21 {'Reserved'}; 22 {'DDR3'}; 24 {'DDR4'}; 26 {'LPDDR3'}; 29 {'LPDDR4'}}}}, Speed, SerialNumber | Out-File -FilePath "output.txt" -Append
echo "  PLACA <--" | Out-File -FilePath "output.txt" -Append
Get-WmiObject -Class Win32_BaseBoard | Select-Object "Manufacturer","Product","SerialNumber" | Out-File -FilePath "output.txt" -Append
echo "  DRIVES <--" | Out-File -FilePath "output.txt" -Append
Get-PhysicalDisk | Select-Object FriendlyName, MediaType, @{Name="Size (GB)"; Expression={$_.Size/1Gb}}, HealthStatus, OperationalStatus, SerialNumber | Out-File -FilePath "output.txt" -Append
echo "  BIOS <--" | Out-File -FilePath "output.txt" -Append
Get-WmiObject -Class Win32_Bios | Out-File -FilePath "output.txt" -Append

echo "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /" | Out-File -FilePath "output.txt" -Append


Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object Username, Model | Out-File -FilePath "regkeys.txt" -Append
reg query HKLM\SOFTWARE\Microsoft\"Windows NT"\CurrentVersion /v DigitalProductId4 | Out-File -FilePath "regkeys.txt" -Append
reg query HKLM\SOFTWARE\Microsoft\"Windows NT"\CurrentVersion /v DigitalProductId  | Out-File -FilePath "regkeys.txt" -Append
echo "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /" | Out-File -FilePath "regkeys.txt" -Append